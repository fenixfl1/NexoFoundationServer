--
-- PostgreSQL database dump
--

\restrict KqZdk7g4P6vHvZhRa6FRavVcWrDWgLT1HVzqDcAuPScgOwlWa5xI8D565jTB6y7

-- Dumped from database version 17.7 (bdd1736)
-- Dumped by pg_dump version 17.7 (Ubuntu 17.7-3.pgdg22.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: unaccent; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS unaccent WITH SCHEMA public;


--
-- Name: EXTENSION unaccent; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION unaccent IS 'text search dictionary that removes accents';


--
-- Name: ACTIVITY_PARTICIPANT_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ACTIVITY_PARTICIPANT_status_enum" AS ENUM (
    'registered',
    'completed',
    'cancelled'
);


--
-- Name: ACTIVITY_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."ACTIVITY_status_enum" AS ENUM (
    'planned',
    'completed',
    'cancelled'
);


--
-- Name: APPOINTMENT_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."APPOINTMENT_status_enum" AS ENUM (
    'scheduled',
    'completed',
    'cancelled'
);


--
-- Name: CONTACT_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CONTACT_type_enum" AS ENUM (
    'email',
    'phone',
    'whatsapp',
    'other'
);


--
-- Name: CONTACT_usage_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CONTACT_usage_enum" AS ENUM (
    'personal',
    'institutional',
    'emergency'
);


--
-- Name: COURSE_GRADE_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."COURSE_GRADE_status_enum" AS ENUM (
    'passed',
    'failed',
    'in_progress'
);


--
-- Name: FOLLOW_UP_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FOLLOW_UP_status_enum" AS ENUM (
    'open',
    'completed',
    'cancelled'
);


--
-- Name: MENU_OPTION_type_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."MENU_OPTION_type_enum" AS ENUM (
    'group',
    'divider',
    'link',
    'item',
    'submenu'
);


--
-- Name: NOTIFICATION_channel_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."NOTIFICATION_channel_enum" AS ENUM (
    'email',
    'sms',
    'in_app',
    'push',
    'whatsapp'
);


--
-- Name: NOTIFICATION_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."NOTIFICATION_status_enum" AS ENUM (
    'P',
    'C',
    'S',
    'F'
);


--
-- Name: REQUEST_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."REQUEST_status_enum" AS ENUM (
    'P',
    'R',
    'A',
    'D',
    'C'
);


--
-- Name: STUDENT_scholarship_status_enum; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."STUDENT_scholarship_status_enum" AS ENUM (
    'P',
    'A',
    'S',
    'C',
    'G'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ACTION; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ACTION" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar NOT NULL,
    "ACTION_ID" integer NOT NULL,
    "NAME" character varying(255) NOT NULL,
    "DESCRIPTION" character varying(255)
);


--
-- Name: ACTION_ACTION_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."ACTION_ACTION_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ACTION_ACTION_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."ACTION_ACTION_ID_seq" OWNED BY public."ACTION"."ACTION_ID";


--
-- Name: ACTIVITY; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ACTIVITY" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "ACTIVITY_ID" integer NOT NULL,
    "TITLE" character varying(150) NOT NULL,
    "DESCRIPTION" text,
    "START_AT" timestamp without time zone NOT NULL,
    "END_AT" timestamp without time zone,
    "LOCATION" character varying(150),
    "HOURS" numeric(4,1) DEFAULT 0 NOT NULL,
    "CAPACITY" integer,
    "STATUS" public."ACTIVITY_status_enum" DEFAULT 'planned'::public."ACTIVITY_status_enum" NOT NULL
);


--
-- Name: ACTIVITY_ACTIVITY_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."ACTIVITY_ACTIVITY_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ACTIVITY_ACTIVITY_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."ACTIVITY_ACTIVITY_ID_seq" OWNED BY public."ACTIVITY"."ACTIVITY_ID";


--
-- Name: ACTIVITY_PARTICIPANT; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ACTIVITY_PARTICIPANT" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "PARTICIPANT_ID" integer NOT NULL,
    "ACTIVITY_ID" integer NOT NULL,
    "STUDENT_ID" integer NOT NULL,
    "STATUS" public."ACTIVITY_PARTICIPANT_status_enum" DEFAULT 'registered'::public."ACTIVITY_PARTICIPANT_status_enum" NOT NULL,
    "HOURS_EARNED" numeric(4,1) DEFAULT 0 NOT NULL,
    "ATTENDED_AT" timestamp without time zone
);


--
-- Name: ACTIVITY_PARTICIPANT_PARTICIPANT_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."ACTIVITY_PARTICIPANT_PARTICIPANT_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ACTIVITY_PARTICIPANT_PARTICIPANT_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."ACTIVITY_PARTICIPANT_PARTICIPANT_ID_seq" OWNED BY public."ACTIVITY_PARTICIPANT"."PARTICIPANT_ID";


--
-- Name: APPOINTMENT; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."APPOINTMENT" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "APPOINTMENT_ID" integer NOT NULL,
    "PERSON_ID" integer NOT NULL,
    "REQUEST_ID" integer,
    "STUDENT_ID" integer,
    "TITLE" character varying(150) NOT NULL,
    "DESCRIPTION" text,
    "START_AT" timestamp without time zone NOT NULL,
    "END_AT" timestamp without time zone,
    "LOCATION" character varying(150),
    "STATUS" public."APPOINTMENT_status_enum" DEFAULT 'scheduled'::public."APPOINTMENT_status_enum" NOT NULL,
    "NOTES" character varying(255)
);


--
-- Name: APPOINTMENT_APPOINTMENT_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."APPOINTMENT_APPOINTMENT_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: APPOINTMENT_APPOINTMENT_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."APPOINTMENT_APPOINTMENT_ID_seq" OWNED BY public."APPOINTMENT"."APPOINTMENT_ID";


--
-- Name: AUDIT_LOG; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."AUDIT_LOG" (
    "AUDIT_LOG_ID" integer NOT NULL,
    "ACTION_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "USER_ID" integer NOT NULL,
    "ENTITY_TYPE" character varying(100) NOT NULL,
    "ENTITY_ID" character varying(100),
    "ENTITY_LABEL" character varying(200) NOT NULL,
    "ACTION" character(1) NOT NULL,
    "MESSAGE" text,
    "PAYLOAD" jsonb,
    "IP_ADDRESS" character varying(45),
    "USER_AGENT" character varying(255),
    CONSTRAINT "CK_AUDIT_LOG_ACTION" CHECK (("ACTION" = ANY (ARRAY['C'::bpchar, 'U'::bpchar, 'D'::bpchar, 'V'::bpchar, 'L'::bpchar])))
);


--
-- Name: AUDIT_LOG_AUDIT_LOG_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."AUDIT_LOG_AUDIT_LOG_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: AUDIT_LOG_AUDIT_LOG_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."AUDIT_LOG_AUDIT_LOG_ID_seq" OWNED BY public."AUDIT_LOG"."AUDIT_LOG_ID";


--
-- Name: BUSINESS; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."BUSINESS" (
    "BUSINESS_ID" integer NOT NULL,
    "NAME" character varying NOT NULL,
    "LOGO" bytea NOT NULL,
    "RNC" character varying NOT NULL,
    "PHONE" character varying NOT NULL,
    "ADDRESS" text NOT NULL,
    "STATE" character(1) NOT NULL
);


--
-- Name: CATALOG; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CATALOG" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "CATALOG_ID" integer NOT NULL,
    "KEY" character varying(100) NOT NULL,
    "NAME" character varying(150) NOT NULL,
    "DESCRIPTION" character varying(255)
);


--
-- Name: CATALOG_CATALOG_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."CATALOG_CATALOG_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: CATALOG_CATALOG_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."CATALOG_CATALOG_ID_seq" OWNED BY public."CATALOG"."CATALOG_ID";


--
-- Name: CATALOG_ITEM; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CATALOG_ITEM" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "ITEM_ID" integer NOT NULL,
    "CATALOG_ID" integer NOT NULL,
    "VALUE" character varying(100) NOT NULL,
    "LABEL" character varying(200) NOT NULL,
    "ORDER" integer DEFAULT 0 NOT NULL,
    "EXTRA" json
);


--
-- Name: CATALOG_ITEM_ITEM_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."CATALOG_ITEM_ITEM_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: CATALOG_ITEM_ITEM_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."CATALOG_ITEM_ITEM_ID_seq" OWNED BY public."CATALOG_ITEM"."ITEM_ID";


--
-- Name: CONTACT; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."CONTACT" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar NOT NULL,
    "CONTACT_ID" integer NOT NULL,
    "PERSON_ID" integer NOT NULL,
    "TYPE" public."CONTACT_type_enum" DEFAULT 'email'::public."CONTACT_type_enum" NOT NULL,
    "USAGE" public."CONTACT_usage_enum" DEFAULT 'personal'::public."CONTACT_usage_enum" NOT NULL,
    "VALUE" character varying(255) NOT NULL,
    "IS_PRIMARY" boolean DEFAULT false NOT NULL
);


--
-- Name: CONTACT_CONTACT_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."CONTACT_CONTACT_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: CONTACT_CONTACT_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."CONTACT_CONTACT_ID_seq" OWNED BY public."CONTACT"."CONTACT_ID";


--
-- Name: COURSE_GRADE; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."COURSE_GRADE" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "COURSE_GRADE_ID" integer NOT NULL,
    "TERM_ID" integer NOT NULL,
    "COURSE_NAME" character varying(150) NOT NULL,
    "GRADE" numeric(4,2) NOT NULL,
    "CREDITS" numeric(4,1) DEFAULT 0 NOT NULL,
    "STATUS" public."COURSE_GRADE_status_enum" DEFAULT 'in_progress'::public."COURSE_GRADE_status_enum" NOT NULL
);


--
-- Name: COURSE_GRADE_COURSE_GRADE_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."COURSE_GRADE_COURSE_GRADE_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: COURSE_GRADE_COURSE_GRADE_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."COURSE_GRADE_COURSE_GRADE_ID_seq" OWNED BY public."COURSE_GRADE"."COURSE_GRADE_ID";


--
-- Name: DEPARTMENT; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DEPARTMENT" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar NOT NULL,
    "DEPARTMENT_ID" integer NOT NULL,
    "NAME" character varying(50) NOT NULL,
    "DESCRIPTION" character varying(100)
);


--
-- Name: DEPARTMENT_DEPARTMENT_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."DEPARTMENT_DEPARTMENT_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: DEPARTMENT_DEPARTMENT_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."DEPARTMENT_DEPARTMENT_ID_seq" OWNED BY public."DEPARTMENT"."DEPARTMENT_ID";


--
-- Name: DISBURSEMENT; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."DISBURSEMENT" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "DISBURSEMENT_ID" integer NOT NULL,
    "SCHOLARSHIP_ID" integer NOT NULL,
    "AMOUNT" numeric(12,2) NOT NULL,
    "DISBURSEMENT_DATE" date NOT NULL,
    "METHOD" character varying(50),
    "REFERENCE" character varying(100),
    "STATUS" character(1) DEFAULT 'P'::bpchar NOT NULL,
    "NOTES" text,
    "COST_ID" integer
);


--
-- Name: DISBURSEMENT_DISBURSEMENT_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."DISBURSEMENT_DISBURSEMENT_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: DISBURSEMENT_DISBURSEMENT_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."DISBURSEMENT_DISBURSEMENT_ID_seq" OWNED BY public."DISBURSEMENT"."DISBURSEMENT_ID";


--
-- Name: FOLLOW_UP; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."FOLLOW_UP" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "FOLLOW_UP_ID" integer NOT NULL,
    "STUDENT_ID" integer NOT NULL,
    "APPOINTMENT_ID" integer,
    "FOLLOW_UP_DATE" timestamp without time zone NOT NULL,
    "SUMMARY" text NOT NULL,
    "NOTES" text,
    "NEXT_APPOINTMENT" timestamp without time zone,
    "STATUS" public."FOLLOW_UP_status_enum" DEFAULT 'open'::public."FOLLOW_UP_status_enum" NOT NULL
);


--
-- Name: FOLLOW_UP_FOLLOW_UP_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."FOLLOW_UP_FOLLOW_UP_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: FOLLOW_UP_FOLLOW_UP_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."FOLLOW_UP_FOLLOW_UP_ID_seq" OWNED BY public."FOLLOW_UP"."FOLLOW_UP_ID";


--
-- Name: MENU_OPTION; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."MENU_OPTION" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar NOT NULL,
    "MENU_OPTION_ID" character varying(50) NOT NULL,
    "NAME" character varying(100) NOT NULL,
    "DESCRIPTION" character varying(250),
    "PATH" character varying(100),
    "TYPE" public."MENU_OPTION_type_enum",
    "ICON" text,
    "ORDER" integer NOT NULL,
    "PARENT_ID" character varying
);


--
-- Name: NOTIFICATION; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."NOTIFICATION" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "NOTIFICATION_ID" integer NOT NULL,
    "TEMPLATE_ID" integer,
    "CHANNEL" public."NOTIFICATION_channel_enum" NOT NULL,
    "RECIPIENT" character varying(255) NOT NULL,
    "SUBJECT" character varying(255),
    "BODY" text NOT NULL,
    "PAYLOAD" jsonb,
    "STATUS" public."NOTIFICATION_status_enum" DEFAULT 'P'::public."NOTIFICATION_status_enum" NOT NULL,
    "RELATED_ENTITY" character varying(100),
    "RELATED_ID" character varying(100),
    "SCHEDULED_AT" timestamp without time zone,
    "SENT_AT" timestamp without time zone,
    "SENT_BY" integer,
    "ERROR_MESSAGE" text
);


--
-- Name: NOTIFICATION_NOTIFICATION_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."NOTIFICATION_NOTIFICATION_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: NOTIFICATION_NOTIFICATION_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."NOTIFICATION_NOTIFICATION_ID_seq" OWNED BY public."NOTIFICATION"."NOTIFICATION_ID";


--
-- Name: NOTIFICATION_TEMPLATE; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."NOTIFICATION_TEMPLATE" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "TEMPLATE_ID" integer NOT NULL,
    "TEMPLATE_KEY" character varying(150) NOT NULL,
    "NAME" character varying(150) NOT NULL,
    "DESCRIPTION" text,
    "CHANNEL" public."NOTIFICATION_channel_enum" NOT NULL,
    "SUBJECT" character varying(255),
    "BODY" text NOT NULL,
    "PARAMETERS" jsonb,
    "DEFAULTS" jsonb,
    "MENU_OPTION_ID" character varying(50)
);


--
-- Name: NOTIFICATION_TEMPLATE_TEMPLATE_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."NOTIFICATION_TEMPLATE_TEMPLATE_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: NOTIFICATION_TEMPLATE_TEMPLATE_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."NOTIFICATION_TEMPLATE_TEMPLATE_ID_seq" OWNED BY public."NOTIFICATION_TEMPLATE"."TEMPLATE_ID";


--
-- Name: PARAMETER; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PARAMETER" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "PARAMETER_ID" integer NOT NULL,
    "PARAMETER" character varying(150) NOT NULL,
    "DESCRIPTION" character varying(255),
    "VALUE" text,
    "MENU_OPTION_ID" character varying(50) NOT NULL
);


--
-- Name: PARAMETER_PARAMETER_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."PARAMETER_PARAMETER_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: PARAMETER_PARAMETER_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."PARAMETER_PARAMETER_ID_seq" OWNED BY public."PARAMETER"."PARAMETER_ID";


--
-- Name: PERMISSION; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PERMISSION" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar NOT NULL,
    "PERMISSION_ID" integer NOT NULL,
    "MENU_OPTION_ID" character varying NOT NULL,
    "ACTION_ID" integer NOT NULL,
    "DESCRIPTION" character varying(255)
);


--
-- Name: PERMISSION_PERMISSION_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."PERMISSION_PERMISSION_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: PERMISSION_PERMISSION_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."PERMISSION_PERMISSION_ID_seq" OWNED BY public."PERMISSION"."PERMISSION_ID";


--
-- Name: PERMISSION_X_ROLE; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PERMISSION_X_ROLE" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar NOT NULL,
    "PERMISSION_ID" integer NOT NULL,
    "ROLE_ID" integer NOT NULL
);


--
-- Name: PERSON; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PERSON" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar NOT NULL,
    "PERSON_ID" integer NOT NULL,
    "NAME" character varying NOT NULL,
    "LAST_NAME" character varying NOT NULL,
    "GENDER" character(1) NOT NULL,
    "BIRTH_DATE" date NOT NULL,
    "IDENTITY_DOCUMENT" character varying NOT NULL,
    "ROLE_ID" integer
);


--
-- Name: PERSON_PERSON_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."PERSON_PERSON_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: PERSON_PERSON_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."PERSON_PERSON_ID_seq" OWNED BY public."PERSON"."PERSON_ID";


--
-- Name: PLEDGE; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."PLEDGE" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "PLEDGE_ID" integer NOT NULL,
    "SPONSOR_ID" integer NOT NULL,
    "NAME" character varying(150) NOT NULL,
    "DESCRIPTION" text,
    "AMOUNT" numeric(12,2) NOT NULL,
    "START_DATE" date NOT NULL,
    "END_DATE" date,
    "FREQUENCY" character varying(30),
    "STATUS" character(1) DEFAULT 'P'::bpchar NOT NULL,
    "NOTES" text
);


--
-- Name: PLEDGE_PLEDGE_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."PLEDGE_PLEDGE_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: PLEDGE_PLEDGE_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."PLEDGE_PLEDGE_ID_seq" OWNED BY public."PLEDGE"."PLEDGE_ID";


--
-- Name: REFERENCE; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."REFERENCE" (
    "REFERENCE_ID" integer NOT NULL,
    "PERSON_ID" integer NOT NULL,
    "RELATIONSHIP" character varying NOT NULL,
    "PHONE" character varying NOT NULL,
    "EMAIL" character varying,
    "ADDRESS" character varying(255),
    "NOTES" character varying(500),
    "FULL_NAME" character varying NOT NULL,
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar NOT NULL
);


--
-- Name: REFERENCE_REFERENCE_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."REFERENCE_REFERENCE_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: REFERENCE_REFERENCE_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."REFERENCE_REFERENCE_ID_seq" OWNED BY public."REFERENCE"."REFERENCE_ID";


--
-- Name: REQUEST; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."REQUEST" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "REQUEST_ID" integer NOT NULL,
    "PERSON_ID" integer NOT NULL,
    "STUDENT_ID" integer,
    "REQUEST_TYPE" character varying(100) NOT NULL,
    "ASSIGNED_COORDINATOR" character varying(150),
    "NEXT_APPOINTMENT" timestamp without time zone,
    "COHORT" character varying(100),
    "NOTES" text,
    "STATUS" public."REQUEST_status_enum" DEFAULT 'P'::public."REQUEST_status_enum"
);


--
-- Name: REQUEST_REQUEST_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."REQUEST_REQUEST_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: REQUEST_REQUEST_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."REQUEST_REQUEST_ID_seq" OWNED BY public."REQUEST"."REQUEST_ID";


--
-- Name: REQUIREMENT; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."REQUIREMENT" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "REQUIREMENT_ID" integer NOT NULL,
    "REQUIREMENT_KEY" character varying(100) NOT NULL,
    "NAME" character varying(150) NOT NULL,
    "DESCRIPTION" text,
    "IS_REQUIRED" boolean DEFAULT true NOT NULL
);


--
-- Name: REQUIREMENT_REQUIREMENT_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."REQUIREMENT_REQUIREMENT_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: REQUIREMENT_REQUIREMENT_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."REQUIREMENT_REQUIREMENT_ID_seq" OWNED BY public."REQUIREMENT"."REQUIREMENT_ID";


--
-- Name: ROLE; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ROLE" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar NOT NULL,
    "ROLE_ID" integer NOT NULL,
    "NAME" character varying(30) NOT NULL,
    "DESCRIPTION" character varying(250) NOT NULL
);


--
-- Name: ROLES_X_USER; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."ROLES_X_USER" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar NOT NULL,
    "USER_ID" integer NOT NULL,
    "ROLE_ID" integer NOT NULL
);


--
-- Name: ROLE_ROLE_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."ROLE_ROLE_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: ROLE_ROLE_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."ROLE_ROLE_ID_seq" OWNED BY public."ROLE"."ROLE_ID";


--
-- Name: SCHOLARSHIP; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SCHOLARSHIP" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "SCHOLARSHIP_ID" integer NOT NULL,
    "STUDENT_ID" integer NOT NULL,
    "REQUEST_ID" integer,
    "NAME" character varying(150) NOT NULL,
    "DESCRIPTION" text,
    "AMOUNT" numeric(12,2) NOT NULL,
    "START_DATE" date NOT NULL,
    "END_DATE" date,
    "STATUS" character(1) DEFAULT 'P'::bpchar NOT NULL,
    "PERIOD_TYPE" character(1) DEFAULT 'S'::bpchar
);


--
-- Name: SCHOLARSHIP_COST_HISTORY; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SCHOLARSHIP_COST_HISTORY" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "COST_ID" integer NOT NULL,
    "SCHOLARSHIP_ID" integer NOT NULL,
    "PERIOD_TYPE" character(1) NOT NULL,
    "PERIOD_LABEL" character varying(30) NOT NULL,
    "PERIOD_START" date NOT NULL,
    "PERIOD_END" date NOT NULL,
    "AMOUNT" numeric(12,2) NOT NULL,
    "STATUS" character(1) DEFAULT 'P'::bpchar NOT NULL,
    "NOTES" text
);


--
-- Name: SCHOLARSHIP_COST_HISTORY_COST_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."SCHOLARSHIP_COST_HISTORY_COST_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: SCHOLARSHIP_COST_HISTORY_COST_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."SCHOLARSHIP_COST_HISTORY_COST_ID_seq" OWNED BY public."SCHOLARSHIP_COST_HISTORY"."COST_ID";


--
-- Name: SCHOLARSHIP_SCHOLARSHIP_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."SCHOLARSHIP_SCHOLARSHIP_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: SCHOLARSHIP_SCHOLARSHIP_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."SCHOLARSHIP_SCHOLARSHIP_ID_seq" OWNED BY public."SCHOLARSHIP"."SCHOLARSHIP_ID";


--
-- Name: SPONSOR; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SPONSOR" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "SPONSOR_ID" integer NOT NULL,
    "NAME" character varying(150) NOT NULL,
    "TYPE" character varying(50),
    "TAX_ID" character varying(30),
    "NOTES" text,
    "PERSON_ID" integer
);


--
-- Name: SPONSOR_SPONSOR_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."SPONSOR_SPONSOR_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: SPONSOR_SPONSOR_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."SPONSOR_SPONSOR_ID_seq" OWNED BY public."SPONSOR"."SPONSOR_ID";


--
-- Name: STUDENT; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."STUDENT" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "STUDENT_ID" integer NOT NULL,
    "PERSON_ID" integer NOT NULL,
    "UNIVERSITY" character varying(150) NOT NULL,
    "CAREER" character varying(150) NOT NULL,
    "SCHOLARSHIP_STATUS" public."STUDENT_scholarship_status_enum" DEFAULT 'P'::public."STUDENT_scholarship_status_enum" NOT NULL,
    "ACADEMIC_AVERAGE" numeric(3,2) DEFAULT '0'::numeric NOT NULL,
    "HOURS_REQUIRED" integer DEFAULT 0 NOT NULL,
    "HOURS_COMPLETED" integer DEFAULT 0 NOT NULL,
    "LAST_FOLLOW_UP" timestamp without time zone,
    "NEXT_APPOINTMENT" timestamp without time zone,
    "COHORT" character varying(100),
    "CAMPUS" character varying(150),
    "SCORE" integer
);


--
-- Name: STUDENT_DOCUMENT; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."STUDENT_DOCUMENT" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "DOCUMENT_ID" integer NOT NULL,
    "STUDENT_ID" integer NOT NULL,
    "DOCUMENT_TYPE" character varying(100) NOT NULL,
    "FILE_NAME" character varying(255) NOT NULL,
    "MIME_TYPE" character varying(100) NOT NULL,
    "FILE_BASE64" text NOT NULL,
    "SIGNED_BASE64" text,
    "SIGNED_AT" timestamp without time zone,
    "DESCRIPTION" text
);


--
-- Name: STUDENT_DOCUMENT_DOCUMENT_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."STUDENT_DOCUMENT_DOCUMENT_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: STUDENT_DOCUMENT_DOCUMENT_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."STUDENT_DOCUMENT_DOCUMENT_ID_seq" OWNED BY public."STUDENT_DOCUMENT"."DOCUMENT_ID";


--
-- Name: STUDENT_REQUIREMENT; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."STUDENT_REQUIREMENT" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "STUDENT_REQUIREMENT_ID" integer NOT NULL,
    "STUDENT_ID" integer NOT NULL,
    "REQUIREMENT_ID" integer NOT NULL,
    "STATUS" character(1) DEFAULT 'P'::bpchar NOT NULL,
    "OBSERVATION" text,
    "VALIDATED_BY" integer,
    "VALIDATED_AT" timestamp without time zone
);


--
-- Name: STUDENT_REQUIREMENT_STUDENT_REQUIREMENT_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."STUDENT_REQUIREMENT_STUDENT_REQUIREMENT_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: STUDENT_REQUIREMENT_STUDENT_REQUIREMENT_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."STUDENT_REQUIREMENT_STUDENT_REQUIREMENT_ID_seq" OWNED BY public."STUDENT_REQUIREMENT"."STUDENT_REQUIREMENT_ID";


--
-- Name: STUDENT_STUDENT_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."STUDENT_STUDENT_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: STUDENT_STUDENT_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."STUDENT_STUDENT_ID_seq" OWNED BY public."STUDENT"."STUDENT_ID";


--
-- Name: TERM; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."TERM" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar,
    "TERM_ID" integer NOT NULL,
    "STUDENT_ID" integer NOT NULL,
    "PERIOD" character varying(20) NOT NULL,
    "TERM_INDEX" numeric(4,2) DEFAULT 0 NOT NULL,
    "TOTAL_CREDITS" integer DEFAULT 0 NOT NULL,
    "CAPTURE_FILE_NAME" character varying(255),
    "CAPTURE_MIME_TYPE" character varying(100),
    "CAPTURE_BASE64" text,
    "OBSERVATIONS" text
);


--
-- Name: TERM_TERM_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."TERM_TERM_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: TERM_TERM_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."TERM_TERM_ID_seq" OWNED BY public."TERM"."TERM_ID";


--
-- Name: USER; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."USER" (
    "CREATED_AT" timestamp without time zone DEFAULT now() NOT NULL,
    "CREATED_BY" integer,
    "STATE" character(1) DEFAULT 'A'::bpchar NOT NULL,
    "USER_ID" integer NOT NULL,
    "USERNAME" character varying(25) NOT NULL,
    "PERSON_ID" integer NOT NULL,
    "PASSWORD" character varying(255) NOT NULL,
    "AVATAR" text
);


--
-- Name: USER_USER_ID_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."USER_USER_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: USER_USER_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."USER_USER_ID_seq" OWNED BY public."USER"."USER_ID";


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    "timestamp" bigint NOT NULL,
    name character varying NOT NULL
);


--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: ACTION ACTION_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ACTION" ALTER COLUMN "ACTION_ID" SET DEFAULT nextval('public."ACTION_ACTION_ID_seq"'::regclass);


--
-- Name: ACTIVITY ACTIVITY_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ACTIVITY" ALTER COLUMN "ACTIVITY_ID" SET DEFAULT nextval('public."ACTIVITY_ACTIVITY_ID_seq"'::regclass);


--
-- Name: ACTIVITY_PARTICIPANT PARTICIPANT_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ACTIVITY_PARTICIPANT" ALTER COLUMN "PARTICIPANT_ID" SET DEFAULT nextval('public."ACTIVITY_PARTICIPANT_PARTICIPANT_ID_seq"'::regclass);


--
-- Name: APPOINTMENT APPOINTMENT_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."APPOINTMENT" ALTER COLUMN "APPOINTMENT_ID" SET DEFAULT nextval('public."APPOINTMENT_APPOINTMENT_ID_seq"'::regclass);


--
-- Name: AUDIT_LOG AUDIT_LOG_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AUDIT_LOG" ALTER COLUMN "AUDIT_LOG_ID" SET DEFAULT nextval('public."AUDIT_LOG_AUDIT_LOG_ID_seq"'::regclass);


--
-- Name: CATALOG CATALOG_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CATALOG" ALTER COLUMN "CATALOG_ID" SET DEFAULT nextval('public."CATALOG_CATALOG_ID_seq"'::regclass);


--
-- Name: CATALOG_ITEM ITEM_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CATALOG_ITEM" ALTER COLUMN "ITEM_ID" SET DEFAULT nextval('public."CATALOG_ITEM_ITEM_ID_seq"'::regclass);


--
-- Name: CONTACT CONTACT_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CONTACT" ALTER COLUMN "CONTACT_ID" SET DEFAULT nextval('public."CONTACT_CONTACT_ID_seq"'::regclass);


--
-- Name: COURSE_GRADE COURSE_GRADE_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."COURSE_GRADE" ALTER COLUMN "COURSE_GRADE_ID" SET DEFAULT nextval('public."COURSE_GRADE_COURSE_GRADE_ID_seq"'::regclass);


--
-- Name: DEPARTMENT DEPARTMENT_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DEPARTMENT" ALTER COLUMN "DEPARTMENT_ID" SET DEFAULT nextval('public."DEPARTMENT_DEPARTMENT_ID_seq"'::regclass);


--
-- Name: DISBURSEMENT DISBURSEMENT_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DISBURSEMENT" ALTER COLUMN "DISBURSEMENT_ID" SET DEFAULT nextval('public."DISBURSEMENT_DISBURSEMENT_ID_seq"'::regclass);


--
-- Name: FOLLOW_UP FOLLOW_UP_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FOLLOW_UP" ALTER COLUMN "FOLLOW_UP_ID" SET DEFAULT nextval('public."FOLLOW_UP_FOLLOW_UP_ID_seq"'::regclass);


--
-- Name: NOTIFICATION NOTIFICATION_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NOTIFICATION" ALTER COLUMN "NOTIFICATION_ID" SET DEFAULT nextval('public."NOTIFICATION_NOTIFICATION_ID_seq"'::regclass);


--
-- Name: NOTIFICATION_TEMPLATE TEMPLATE_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NOTIFICATION_TEMPLATE" ALTER COLUMN "TEMPLATE_ID" SET DEFAULT nextval('public."NOTIFICATION_TEMPLATE_TEMPLATE_ID_seq"'::regclass);


--
-- Name: PARAMETER PARAMETER_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PARAMETER" ALTER COLUMN "PARAMETER_ID" SET DEFAULT nextval('public."PARAMETER_PARAMETER_ID_seq"'::regclass);


--
-- Name: PERMISSION PERMISSION_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PERMISSION" ALTER COLUMN "PERMISSION_ID" SET DEFAULT nextval('public."PERMISSION_PERMISSION_ID_seq"'::regclass);


--
-- Name: PERSON PERSON_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PERSON" ALTER COLUMN "PERSON_ID" SET DEFAULT nextval('public."PERSON_PERSON_ID_seq"'::regclass);


--
-- Name: PLEDGE PLEDGE_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PLEDGE" ALTER COLUMN "PLEDGE_ID" SET DEFAULT nextval('public."PLEDGE_PLEDGE_ID_seq"'::regclass);


--
-- Name: REFERENCE REFERENCE_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."REFERENCE" ALTER COLUMN "REFERENCE_ID" SET DEFAULT nextval('public."REFERENCE_REFERENCE_ID_seq"'::regclass);


--
-- Name: REQUEST REQUEST_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."REQUEST" ALTER COLUMN "REQUEST_ID" SET DEFAULT nextval('public."REQUEST_REQUEST_ID_seq"'::regclass);


--
-- Name: REQUIREMENT REQUIREMENT_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."REQUIREMENT" ALTER COLUMN "REQUIREMENT_ID" SET DEFAULT nextval('public."REQUIREMENT_REQUIREMENT_ID_seq"'::regclass);


--
-- Name: ROLE ROLE_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ROLE" ALTER COLUMN "ROLE_ID" SET DEFAULT nextval('public."ROLE_ROLE_ID_seq"'::regclass);


--
-- Name: SCHOLARSHIP SCHOLARSHIP_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SCHOLARSHIP" ALTER COLUMN "SCHOLARSHIP_ID" SET DEFAULT nextval('public."SCHOLARSHIP_SCHOLARSHIP_ID_seq"'::regclass);


--
-- Name: SCHOLARSHIP_COST_HISTORY COST_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SCHOLARSHIP_COST_HISTORY" ALTER COLUMN "COST_ID" SET DEFAULT nextval('public."SCHOLARSHIP_COST_HISTORY_COST_ID_seq"'::regclass);


--
-- Name: SPONSOR SPONSOR_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SPONSOR" ALTER COLUMN "SPONSOR_ID" SET DEFAULT nextval('public."SPONSOR_SPONSOR_ID_seq"'::regclass);


--
-- Name: STUDENT STUDENT_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."STUDENT" ALTER COLUMN "STUDENT_ID" SET DEFAULT nextval('public."STUDENT_STUDENT_ID_seq"'::regclass);


--
-- Name: STUDENT_DOCUMENT DOCUMENT_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."STUDENT_DOCUMENT" ALTER COLUMN "DOCUMENT_ID" SET DEFAULT nextval('public."STUDENT_DOCUMENT_DOCUMENT_ID_seq"'::regclass);


--
-- Name: STUDENT_REQUIREMENT STUDENT_REQUIREMENT_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."STUDENT_REQUIREMENT" ALTER COLUMN "STUDENT_REQUIREMENT_ID" SET DEFAULT nextval('public."STUDENT_REQUIREMENT_STUDENT_REQUIREMENT_ID_seq"'::regclass);


--
-- Name: TERM TERM_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TERM" ALTER COLUMN "TERM_ID" SET DEFAULT nextval('public."TERM_TERM_ID_seq"'::regclass);


--
-- Name: USER USER_ID; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."USER" ALTER COLUMN "USER_ID" SET DEFAULT nextval('public."USER_USER_ID_seq"'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: PERSON PK_18197183747b37c419fcc02f2f1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PERSON"
    ADD CONSTRAINT "PK_18197183747b37c419fcc02f2f1" PRIMARY KEY ("PERSON_ID");


--
-- Name: ROLE PK_2464e6137ccbd5f89724b83282e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ROLE"
    ADD CONSTRAINT "PK_2464e6137ccbd5f89724b83282e" PRIMARY KEY ("ROLE_ID");


--
-- Name: ROLES_X_USER PK_27488ae7e50440d4a06b585798b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ROLES_X_USER"
    ADD CONSTRAINT "PK_27488ae7e50440d4a06b585798b" PRIMARY KEY ("USER_ID", "ROLE_ID");


--
-- Name: PERMISSION PK_7efad0105d237300cbd89505d3d; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PERMISSION"
    ADD CONSTRAINT "PK_7efad0105d237300cbd89505d3d" PRIMARY KEY ("PERMISSION_ID");


--
-- Name: CONTACT PK_823580c7d4d521ccf9cd58cbb16; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CONTACT"
    ADD CONSTRAINT "PK_823580c7d4d521ccf9cd58cbb16" PRIMARY KEY ("CONTACT_ID");


--
-- Name: USER PK_83bc997badef7070d50845f1e9b; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."USER"
    ADD CONSTRAINT "PK_83bc997badef7070d50845f1e9b" PRIMARY KEY ("USER_ID");


--
-- Name: BUSINESS PK_8726e67e668478ef7d1aedd6a0e; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."BUSINESS"
    ADD CONSTRAINT "PK_8726e67e668478ef7d1aedd6a0e" PRIMARY KEY ("BUSINESS_ID");


--
-- Name: migrations PK_8c82d7f526340ab734260ea46be; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT "PK_8c82d7f526340ab734260ea46be" PRIMARY KEY (id);


--
-- Name: REFERENCE PK_92aff10276e579b1080a24449b9; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."REFERENCE"
    ADD CONSTRAINT "PK_92aff10276e579b1080a24449b9" PRIMARY KEY ("REFERENCE_ID");


--
-- Name: ACTIVITY PK_ACTIVITY; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ACTIVITY"
    ADD CONSTRAINT "PK_ACTIVITY" PRIMARY KEY ("ACTIVITY_ID");


--
-- Name: ACTIVITY_PARTICIPANT PK_ACTIVITY_PARTICIPANT; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ACTIVITY_PARTICIPANT"
    ADD CONSTRAINT "PK_ACTIVITY_PARTICIPANT" PRIMARY KEY ("PARTICIPANT_ID");


--
-- Name: APPOINTMENT PK_APPOINTMENT; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."APPOINTMENT"
    ADD CONSTRAINT "PK_APPOINTMENT" PRIMARY KEY ("APPOINTMENT_ID");


--
-- Name: AUDIT_LOG PK_AUDIT_LOG; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AUDIT_LOG"
    ADD CONSTRAINT "PK_AUDIT_LOG" PRIMARY KEY ("AUDIT_LOG_ID");


--
-- Name: CATALOG PK_CATALOG; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CATALOG"
    ADD CONSTRAINT "PK_CATALOG" PRIMARY KEY ("CATALOG_ID");


--
-- Name: CATALOG_ITEM PK_CATALOG_ITEM; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CATALOG_ITEM"
    ADD CONSTRAINT "PK_CATALOG_ITEM" PRIMARY KEY ("ITEM_ID");


--
-- Name: COURSE_GRADE PK_COURSE_GRADE; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."COURSE_GRADE"
    ADD CONSTRAINT "PK_COURSE_GRADE" PRIMARY KEY ("COURSE_GRADE_ID");


--
-- Name: DISBURSEMENT PK_DISBURSEMENT; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DISBURSEMENT"
    ADD CONSTRAINT "PK_DISBURSEMENT" PRIMARY KEY ("DISBURSEMENT_ID");


--
-- Name: FOLLOW_UP PK_FOLLOW_UP; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FOLLOW_UP"
    ADD CONSTRAINT "PK_FOLLOW_UP" PRIMARY KEY ("FOLLOW_UP_ID");


--
-- Name: NOTIFICATION PK_NOTIFICATION; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NOTIFICATION"
    ADD CONSTRAINT "PK_NOTIFICATION" PRIMARY KEY ("NOTIFICATION_ID");


--
-- Name: NOTIFICATION_TEMPLATE PK_NOTIFICATION_TEMPLATE; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NOTIFICATION_TEMPLATE"
    ADD CONSTRAINT "PK_NOTIFICATION_TEMPLATE" PRIMARY KEY ("TEMPLATE_ID");


--
-- Name: PARAMETER PK_PARAMETER; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PARAMETER"
    ADD CONSTRAINT "PK_PARAMETER" PRIMARY KEY ("PARAMETER_ID");


--
-- Name: PLEDGE PK_PLEDGE; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PLEDGE"
    ADD CONSTRAINT "PK_PLEDGE" PRIMARY KEY ("PLEDGE_ID");


--
-- Name: REQUEST PK_REQUEST; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."REQUEST"
    ADD CONSTRAINT "PK_REQUEST" PRIMARY KEY ("REQUEST_ID");


--
-- Name: REQUIREMENT PK_REQUIREMENT; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."REQUIREMENT"
    ADD CONSTRAINT "PK_REQUIREMENT" PRIMARY KEY ("REQUIREMENT_ID");


--
-- Name: SCHOLARSHIP PK_SCHOLARSHIP; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SCHOLARSHIP"
    ADD CONSTRAINT "PK_SCHOLARSHIP" PRIMARY KEY ("SCHOLARSHIP_ID");


--
-- Name: SCHOLARSHIP_COST_HISTORY PK_SCHOLARSHIP_COST_HISTORY; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SCHOLARSHIP_COST_HISTORY"
    ADD CONSTRAINT "PK_SCHOLARSHIP_COST_HISTORY" PRIMARY KEY ("COST_ID");


--
-- Name: SPONSOR PK_SPONSOR; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SPONSOR"
    ADD CONSTRAINT "PK_SPONSOR" PRIMARY KEY ("SPONSOR_ID");


--
-- Name: STUDENT PK_STUDENT; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."STUDENT"
    ADD CONSTRAINT "PK_STUDENT" PRIMARY KEY ("STUDENT_ID");


--
-- Name: STUDENT_DOCUMENT PK_STUDENT_DOCUMENT; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."STUDENT_DOCUMENT"
    ADD CONSTRAINT "PK_STUDENT_DOCUMENT" PRIMARY KEY ("DOCUMENT_ID");


--
-- Name: STUDENT_REQUIREMENT PK_STUDENT_REQUIREMENT; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."STUDENT_REQUIREMENT"
    ADD CONSTRAINT "PK_STUDENT_REQUIREMENT" PRIMARY KEY ("STUDENT_REQUIREMENT_ID");


--
-- Name: TERM PK_TERM; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TERM"
    ADD CONSTRAINT "PK_TERM" PRIMARY KEY ("TERM_ID");


--
-- Name: PERMISSION_X_ROLE PK_aba3c897a024c6ba7edf7a47da3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PERMISSION_X_ROLE"
    ADD CONSTRAINT "PK_aba3c897a024c6ba7edf7a47da3" PRIMARY KEY ("PERMISSION_ID", "ROLE_ID");


--
-- Name: DEPARTMENT PK_b3142394ad5073f4a21ef3df9c4; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DEPARTMENT"
    ADD CONSTRAINT "PK_b3142394ad5073f4a21ef3df9c4" PRIMARY KEY ("DEPARTMENT_ID");


--
-- Name: MENU_OPTION PK_c33923d6f156b267e8e4dfe59c3; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MENU_OPTION"
    ADD CONSTRAINT "PK_c33923d6f156b267e8e4dfe59c3" PRIMARY KEY ("MENU_OPTION_ID");


--
-- Name: ACTION PK_dfc4a3ad12020abd40ef5d092ac; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ACTION"
    ADD CONSTRAINT "PK_dfc4a3ad12020abd40ef5d092ac" PRIMARY KEY ("ACTION_ID");


--
-- Name: USER UQ_32060ff68c49165df39813b40b7; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."USER"
    ADD CONSTRAINT "UQ_32060ff68c49165df39813b40b7" UNIQUE ("PERSON_ID");


--
-- Name: CATALOG_ITEM UQ_CATALOG_ITEM_VALUE; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CATALOG_ITEM"
    ADD CONSTRAINT "UQ_CATALOG_ITEM_VALUE" UNIQUE ("CATALOG_ID", "VALUE");


--
-- Name: CATALOG UQ_CATALOG_KEY; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CATALOG"
    ADD CONSTRAINT "UQ_CATALOG_KEY" UNIQUE ("KEY");


--
-- Name: NOTIFICATION_TEMPLATE UQ_NOTIFICATION_TEMPLATE_KEY; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NOTIFICATION_TEMPLATE"
    ADD CONSTRAINT "UQ_NOTIFICATION_TEMPLATE_KEY" UNIQUE ("TEMPLATE_KEY");


--
-- Name: PARAMETER UQ_PARAMETER_MENU_OPTION; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PARAMETER"
    ADD CONSTRAINT "UQ_PARAMETER_MENU_OPTION" UNIQUE ("MENU_OPTION_ID", "PARAMETER");


--
-- Name: REQUIREMENT UQ_REQUIREMENT_KEY; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."REQUIREMENT"
    ADD CONSTRAINT "UQ_REQUIREMENT_KEY" UNIQUE ("REQUIREMENT_KEY");


--
-- Name: SCHOLARSHIP_COST_HISTORY UQ_SCHOLARSHIP_COST_UNIQUE; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SCHOLARSHIP_COST_HISTORY"
    ADD CONSTRAINT "UQ_SCHOLARSHIP_COST_UNIQUE" UNIQUE ("SCHOLARSHIP_ID", "PERIOD_LABEL");


--
-- Name: STUDENT_REQUIREMENT UQ_STUDENT_REQUIREMENT; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."STUDENT_REQUIREMENT"
    ADD CONSTRAINT "UQ_STUDENT_REQUIREMENT" UNIQUE ("STUDENT_ID", "REQUIREMENT_ID");


--
-- Name: ROLE UQ_cfcd3a13b39580bf95cd2ef1b1f; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ROLE"
    ADD CONSTRAINT "UQ_cfcd3a13b39580bf95cd2ef1b1f" UNIQUE ("NAME");


--
-- Name: USER UQ_d02ca672152e744cf7ba53d2864; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."USER"
    ADD CONSTRAINT "UQ_d02ca672152e744cf7ba53d2864" UNIQUE ("USERNAME");


--
-- Name: IDX_741e323799d657b06d86ca98cb; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "IDX_741e323799d657b06d86ca98cb" ON public."CONTACT" USING btree ("PERSON_ID", "TYPE", "USAGE", "VALUE");


--
-- Name: IDX_AUDIT_LOG_ACTION_AT; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_AUDIT_LOG_ACTION_AT" ON public."AUDIT_LOG" USING btree ("ACTION_AT");


--
-- Name: IDX_AUDIT_LOG_ENTITY; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_AUDIT_LOG_ENTITY" ON public."AUDIT_LOG" USING btree ("ENTITY_TYPE");


--
-- Name: IDX_AUDIT_LOG_USER; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_AUDIT_LOG_USER" ON public."AUDIT_LOG" USING btree ("USER_ID");


--
-- Name: IDX_NOTIFICATION_RELATED; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_NOTIFICATION_RELATED" ON public."NOTIFICATION" USING btree ("RELATED_ENTITY", "RELATED_ID");


--
-- Name: IDX_NOTIFICATION_STATUS; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_NOTIFICATION_STATUS" ON public."NOTIFICATION" USING btree ("STATUS");


--
-- Name: IDX_NOTIFICATION_TEMPLATE; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "IDX_NOTIFICATION_TEMPLATE" ON public."NOTIFICATION" USING btree ("TEMPLATE_ID");


--
-- Name: MENU_OPTION FK_1f20d78a9ea67f0564538ea95f7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."MENU_OPTION"
    ADD CONSTRAINT "FK_1f20d78a9ea67f0564538ea95f7" FOREIGN KEY ("PARENT_ID") REFERENCES public."MENU_OPTION"("MENU_OPTION_ID");


--
-- Name: PERMISSION_X_ROLE FK_24cb3d11068904d9544b5add23b; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PERMISSION_X_ROLE"
    ADD CONSTRAINT "FK_24cb3d11068904d9544b5add23b" FOREIGN KEY ("PERMISSION_ID") REFERENCES public."PERMISSION"("PERMISSION_ID");


--
-- Name: USER FK_32060ff68c49165df39813b40b7; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."USER"
    ADD CONSTRAINT "FK_32060ff68c49165df39813b40b7" FOREIGN KEY ("PERSON_ID") REFERENCES public."PERSON"("PERSON_ID");


--
-- Name: PERMISSION FK_3c9b3cee370052f5bba1d4805af; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PERMISSION"
    ADD CONSTRAINT "FK_3c9b3cee370052f5bba1d4805af" FOREIGN KEY ("MENU_OPTION_ID") REFERENCES public."MENU_OPTION"("MENU_OPTION_ID");


--
-- Name: PERMISSION FK_3e0bac09494fb052114349b2a62; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PERMISSION"
    ADD CONSTRAINT "FK_3e0bac09494fb052114349b2a62" FOREIGN KEY ("ACTION_ID") REFERENCES public."ACTION"("ACTION_ID");


--
-- Name: REFERENCE FK_3fae0bec510324822c68b9fb0ea; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."REFERENCE"
    ADD CONSTRAINT "FK_3fae0bec510324822c68b9fb0ea" FOREIGN KEY ("PERSON_ID") REFERENCES public."PERSON"("PERSON_ID");


--
-- Name: CONTACT FK_4c2187d589e711ace441c01a922; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CONTACT"
    ADD CONSTRAINT "FK_4c2187d589e711ace441c01a922" FOREIGN KEY ("PERSON_ID") REFERENCES public."PERSON"("PERSON_ID");


--
-- Name: ROLES_X_USER FK_6014c0ac471a029270386464b0e; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ROLES_X_USER"
    ADD CONSTRAINT "FK_6014c0ac471a029270386464b0e" FOREIGN KEY ("USER_ID") REFERENCES public."USER"("USER_ID");


--
-- Name: ACTIVITY_PARTICIPANT FK_ACTIVITY_PARTICIPANT_ACTIVITY; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ACTIVITY_PARTICIPANT"
    ADD CONSTRAINT "FK_ACTIVITY_PARTICIPANT_ACTIVITY" FOREIGN KEY ("ACTIVITY_ID") REFERENCES public."ACTIVITY"("ACTIVITY_ID") ON DELETE CASCADE;


--
-- Name: ACTIVITY_PARTICIPANT FK_ACTIVITY_PARTICIPANT_STUDENT; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ACTIVITY_PARTICIPANT"
    ADD CONSTRAINT "FK_ACTIVITY_PARTICIPANT_STUDENT" FOREIGN KEY ("STUDENT_ID") REFERENCES public."STUDENT"("STUDENT_ID") ON DELETE CASCADE;


--
-- Name: APPOINTMENT FK_APPOINTMENT_PERSON; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."APPOINTMENT"
    ADD CONSTRAINT "FK_APPOINTMENT_PERSON" FOREIGN KEY ("PERSON_ID") REFERENCES public."PERSON"("PERSON_ID");


--
-- Name: APPOINTMENT FK_APPOINTMENT_REQUEST; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."APPOINTMENT"
    ADD CONSTRAINT "FK_APPOINTMENT_REQUEST" FOREIGN KEY ("REQUEST_ID") REFERENCES public."REQUEST"("REQUEST_ID") ON DELETE SET NULL;


--
-- Name: APPOINTMENT FK_APPOINTMENT_STUDENT; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."APPOINTMENT"
    ADD CONSTRAINT "FK_APPOINTMENT_STUDENT" FOREIGN KEY ("STUDENT_ID") REFERENCES public."STUDENT"("STUDENT_ID") ON DELETE SET NULL;


--
-- Name: AUDIT_LOG FK_AUDIT_LOG_USER; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."AUDIT_LOG"
    ADD CONSTRAINT "FK_AUDIT_LOG_USER" FOREIGN KEY ("USER_ID") REFERENCES public."USER"("USER_ID");


--
-- Name: CATALOG_ITEM FK_CATALOG_ITEM_CATALOG; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."CATALOG_ITEM"
    ADD CONSTRAINT "FK_CATALOG_ITEM_CATALOG" FOREIGN KEY ("CATALOG_ID") REFERENCES public."CATALOG"("CATALOG_ID") ON DELETE CASCADE;


--
-- Name: SCHOLARSHIP_COST_HISTORY FK_COST_HISTORY_SCHOLARSHIP; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SCHOLARSHIP_COST_HISTORY"
    ADD CONSTRAINT "FK_COST_HISTORY_SCHOLARSHIP" FOREIGN KEY ("SCHOLARSHIP_ID") REFERENCES public."SCHOLARSHIP"("SCHOLARSHIP_ID");


--
-- Name: COURSE_GRADE FK_COURSE_GRADE_TERM; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."COURSE_GRADE"
    ADD CONSTRAINT "FK_COURSE_GRADE_TERM" FOREIGN KEY ("TERM_ID") REFERENCES public."TERM"("TERM_ID") ON DELETE CASCADE;


--
-- Name: DISBURSEMENT FK_DISBURSEMENT_COST_HISTORY; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DISBURSEMENT"
    ADD CONSTRAINT "FK_DISBURSEMENT_COST_HISTORY" FOREIGN KEY ("COST_ID") REFERENCES public."SCHOLARSHIP_COST_HISTORY"("COST_ID");


--
-- Name: DISBURSEMENT FK_DISBURSEMENT_SCHOLARSHIP; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."DISBURSEMENT"
    ADD CONSTRAINT "FK_DISBURSEMENT_SCHOLARSHIP" FOREIGN KEY ("SCHOLARSHIP_ID") REFERENCES public."SCHOLARSHIP"("SCHOLARSHIP_ID");


--
-- Name: FOLLOW_UP FK_FOLLOW_UP_APPOINTMENT; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FOLLOW_UP"
    ADD CONSTRAINT "FK_FOLLOW_UP_APPOINTMENT" FOREIGN KEY ("APPOINTMENT_ID") REFERENCES public."APPOINTMENT"("APPOINTMENT_ID") ON DELETE SET NULL;


--
-- Name: FOLLOW_UP FK_FOLLOW_UP_STUDENT; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."FOLLOW_UP"
    ADD CONSTRAINT "FK_FOLLOW_UP_STUDENT" FOREIGN KEY ("STUDENT_ID") REFERENCES public."STUDENT"("STUDENT_ID");


--
-- Name: NOTIFICATION FK_NOTIFICATION_SENT_BY_USER; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NOTIFICATION"
    ADD CONSTRAINT "FK_NOTIFICATION_SENT_BY_USER" FOREIGN KEY ("SENT_BY") REFERENCES public."USER"("USER_ID") ON DELETE SET NULL;


--
-- Name: NOTIFICATION FK_NOTIFICATION_TEMPLATE; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NOTIFICATION"
    ADD CONSTRAINT "FK_NOTIFICATION_TEMPLATE" FOREIGN KEY ("TEMPLATE_ID") REFERENCES public."NOTIFICATION_TEMPLATE"("TEMPLATE_ID") ON DELETE SET NULL;


--
-- Name: NOTIFICATION_TEMPLATE FK_NOTIFICATION_TEMPLATE_MENU_OPTION; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."NOTIFICATION_TEMPLATE"
    ADD CONSTRAINT "FK_NOTIFICATION_TEMPLATE_MENU_OPTION" FOREIGN KEY ("MENU_OPTION_ID") REFERENCES public."MENU_OPTION"("MENU_OPTION_ID") ON DELETE SET NULL;


--
-- Name: PARAMETER FK_PARAMETER_MENU_OPTION; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PARAMETER"
    ADD CONSTRAINT "FK_PARAMETER_MENU_OPTION" FOREIGN KEY ("MENU_OPTION_ID") REFERENCES public."MENU_OPTION"("MENU_OPTION_ID") ON DELETE CASCADE;


--
-- Name: PERSON FK_PERSON_ROLE; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PERSON"
    ADD CONSTRAINT "FK_PERSON_ROLE" FOREIGN KEY ("ROLE_ID") REFERENCES public."ROLE"("ROLE_ID");


--
-- Name: PLEDGE FK_PLEDGE_SPONSOR; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PLEDGE"
    ADD CONSTRAINT "FK_PLEDGE_SPONSOR" FOREIGN KEY ("SPONSOR_ID") REFERENCES public."SPONSOR"("SPONSOR_ID");


--
-- Name: REQUEST FK_REQUEST_PERSON; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."REQUEST"
    ADD CONSTRAINT "FK_REQUEST_PERSON" FOREIGN KEY ("PERSON_ID") REFERENCES public."PERSON"("PERSON_ID");


--
-- Name: REQUEST FK_REQUEST_STUDENT; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."REQUEST"
    ADD CONSTRAINT "FK_REQUEST_STUDENT" FOREIGN KEY ("STUDENT_ID") REFERENCES public."STUDENT"("STUDENT_ID");


--
-- Name: SCHOLARSHIP FK_SCHOLARSHIP_REQUEST; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SCHOLARSHIP"
    ADD CONSTRAINT "FK_SCHOLARSHIP_REQUEST" FOREIGN KEY ("REQUEST_ID") REFERENCES public."REQUEST"("REQUEST_ID");


--
-- Name: SCHOLARSHIP FK_SCHOLARSHIP_STUDENT; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SCHOLARSHIP"
    ADD CONSTRAINT "FK_SCHOLARSHIP_STUDENT" FOREIGN KEY ("STUDENT_ID") REFERENCES public."STUDENT"("STUDENT_ID");


--
-- Name: SPONSOR FK_SPONSOR_PERSON; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SPONSOR"
    ADD CONSTRAINT "FK_SPONSOR_PERSON" FOREIGN KEY ("PERSON_ID") REFERENCES public."PERSON"("PERSON_ID") ON DELETE SET NULL;


--
-- Name: STUDENT_DOCUMENT FK_STUDENT_DOCUMENT_STUDENT; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."STUDENT_DOCUMENT"
    ADD CONSTRAINT "FK_STUDENT_DOCUMENT_STUDENT" FOREIGN KEY ("STUDENT_ID") REFERENCES public."STUDENT"("STUDENT_ID");


--
-- Name: STUDENT FK_STUDENT_PERSON; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."STUDENT"
    ADD CONSTRAINT "FK_STUDENT_PERSON" FOREIGN KEY ("PERSON_ID") REFERENCES public."PERSON"("PERSON_ID");


--
-- Name: STUDENT_REQUIREMENT FK_STUDENT_REQUIREMENT_REQUIREMENT; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."STUDENT_REQUIREMENT"
    ADD CONSTRAINT "FK_STUDENT_REQUIREMENT_REQUIREMENT" FOREIGN KEY ("REQUIREMENT_ID") REFERENCES public."REQUIREMENT"("REQUIREMENT_ID");


--
-- Name: STUDENT_REQUIREMENT FK_STUDENT_REQUIREMENT_STUDENT; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."STUDENT_REQUIREMENT"
    ADD CONSTRAINT "FK_STUDENT_REQUIREMENT_STUDENT" FOREIGN KEY ("STUDENT_ID") REFERENCES public."STUDENT"("STUDENT_ID");


--
-- Name: STUDENT_REQUIREMENT FK_STUDENT_REQUIREMENT_VALIDATED_BY; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."STUDENT_REQUIREMENT"
    ADD CONSTRAINT "FK_STUDENT_REQUIREMENT_VALIDATED_BY" FOREIGN KEY ("VALIDATED_BY") REFERENCES public."USER"("USER_ID");


--
-- Name: TERM FK_TERM_STUDENT; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."TERM"
    ADD CONSTRAINT "FK_TERM_STUDENT" FOREIGN KEY ("STUDENT_ID") REFERENCES public."STUDENT"("STUDENT_ID");


--
-- Name: PERMISSION_X_ROLE FK_ae267066b6f7555d2adb197c85a; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."PERMISSION_X_ROLE"
    ADD CONSTRAINT "FK_ae267066b6f7555d2adb197c85a" FOREIGN KEY ("ROLE_ID") REFERENCES public."ROLE"("ROLE_ID");


--
-- Name: ROLES_X_USER FK_cfb5ba942f33086e54cec026244; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."ROLES_X_USER"
    ADD CONSTRAINT "FK_cfb5ba942f33086e54cec026244" FOREIGN KEY ("ROLE_ID") REFERENCES public."ROLE"("ROLE_ID");


--
-- PostgreSQL database dump complete
--

\unrestrict KqZdk7g4P6vHvZhRa6FRavVcWrDWgLT1HVzqDcAuPScgOwlWa5xI8D565jTB6y7

